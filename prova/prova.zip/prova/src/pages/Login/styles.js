import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({

  conteiner:{
    marginTop: 0,
    flex: 1,
    flexDirection: 'column'
  },
  view:{
    flexDirection: 'row',
    alignSelf: 'center'
  },
  image:{
    height: 500,
    resizeMode: 'cover'
  },
  login:{
      marginTop: 150,
      marginBottom: 30,
      alignSelf: 'center',
      fontSize: 35,
      fontWeight: 'bold',
      color: 'white'
  },
  input:{
      width: 180,
      borderWidth: 3,
      borderColor: 'white',
      marginLeft: 0,
      fontSize: 15,
      padding: 15,
      borderRadius: 8,
      color: 'white',
      flexDirection: 'row',
      fontWeight: 'bold',
      backgroundColor: 'rgba(255,255,255,0.3)'
  },
  picker:{
      fontSize: 15,
      paddingHorizontal: 15,
      paddingVertical: 8,
      borderWidth: 3,
      borderColor: 'white',
      borderRadius: 8,
      color: 'white',
      flexDirection: 'row',
      width: 110,
      fontWeight: 'bold',
      backgroundColor: 'rgba(255,255,255,0.3)'
  },
  buscar: {
      alignSelf: 'center',
      color: 'white',
      fontWeight: 'bold',
      fontFamily: 'System'
  },
  opacity: {
    backgroundColor: 'rgba(255,255,255,0.3)',
    alignSelf: 'center',
      marginTop: 5,
      borderRadius: 8,
      padding: 10,
      borderWidth: 3,
      color: 'white',
      borderColor: 'white',
      fontWeight: 'bod',
      width: 110,
      fontFamily: 'System'
  },
  dados: {
    color: 'white'
  }

});

export {styles};
