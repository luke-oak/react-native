import React, { useState } from 'react';
import { SafeAreaView, View, Text, TextInput, ImageBackground, Pressable, TouchableOpacity} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import {Picker} from '@react-native-picker/picker';
import { styles } from './styles';
import api from '../../services/api';


export default function Login(){
  const navigation = useNavigation();
  
  const image = {uri: 'https://images8.alphacoders.com/128/1281654.jpg'};
  const [summoner, setSummoner] = useState('')
  const [summonerSemEspaco, setSummonerSemEspaco] = useState('');
  const [dadosSummoner, setDadosSummoner] = useState([]);

  const tiraEspaco = () => {
    const summonerSemEspaco = summoner.replace(/ /g, '%20');
    setSummonerSemEspaco(summonerSemEspaco);
  };

  const busca = async (summonerSemEspaco) => {
      const response = await api.get('/' + summonerSemEspaco, {
      headers: {
        "X-Riot-Token": "RGAPI-9c575709-e2fc-4903-9b1d-e9a9b25779f2",
            },
          }
      );
      setDadosSummoner(response.data)
      //navigation.navigate('Home');
    }

  return(
    <SafeAreaView style = {styles.conteiner}>
      <ImageBackground source = {image} style = {styles.image} resizeMode="cover">
        <Text style = {styles.login} >JAX.GG</Text>
        <View style = {styles.view}> 
          <TextInput
            style = {styles.input}
            onChangeText={setSummoner}
            placeholder = 'Nome de invocador'
            value={summoner}
            underlineColorAndroid="transparent"
          />
        </View>
        <TouchableOpacity style = {styles.opacity}
        onPressIn = {tiraEspaco}
        onPressOut = {busca(summonerSemEspaco)}>
        <Text style = {styles.buscar}>BUSCAR🔎</Text>
        </TouchableOpacity>
        <Text style={styles.dados}>PUUId: {dadosSummoner?.puuid}</Text>
        <Text style={styles.dados}>Nome: {dadosSummoner?.nome}</Text>
        <Text style={styles.dados}>Icone de perfil: {dadosSummoner?.profileIconId}</Text>
        

      </ImageBackground>
    </SafeAreaView>
  )
}

