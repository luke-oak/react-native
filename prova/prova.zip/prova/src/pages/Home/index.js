import React, { useState } from 'react';
import { View, Text, Button, TextInput} from 'react-native';
import { useNavigation } from '@react-navigation/native';

export default function Home(){
  return(
    <View>
      <Text>Home</Text>
    </View>
  )
}
